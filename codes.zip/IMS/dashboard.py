# from tkinter import*
# from PIL import Image,ImageTk
# class IMS:
#     def  __init__(self,root):
#         self.root = root
#         self.root.geometry("1350x700+0+0")
#         self.root.title("Inventory Management System")
#         self.root.config(bg="white")
        
#         self.icon_title = PhotoImage(file="images/membrane-logo.png")
#         title = Label(self.root,text="Inventory Management System",image=self.icon_title,compound=LEFT,font=("times new roman",30,"bold"),bg="darkblue",fg="white",cursor = "hand2",anchor="w",padx=20).place(x=0,y=0,relwidth=1,height=70)

#         #logout butotn
#         btn_logout = Button(self.root,text = "Logout",font=("times new roman0",15,"bold"),bg="yellow",cursor="hand2").place(x=1150,y=10,height=50,width=150)

#         #clock
#         self.label_clock = Label(self.root,text="Welcome to Inventory Management System\t\t Date: DD-MM-YYYY\t\t Time: HH:MM:SS",font=("times new roman",15),bg="grey",fg="white")
#         self.label_clock.place(x=0,y=70,relwidth=1,height=30)


#         #Left menu 
#         self.MenuLogo = Image.open("images/logo.jpeg")
#         self.MenuLogo = self.MenuLogo.resize((200,200))
#         self.MenuLogo=ImageTk.PhotoImage(self.MenuLogo)
 
#         Leftmenu=Frame(self.root,bd=2,relief=RIDGE,bg="white")
#         Leftmenu.place(x=0,y=102,width=200,height=565)

#         Label_menulogo = Label(Leftmenu,image=self.MenuLogo)
#         Label_menulogo.pack(side=TOP,fill=X)
 
#         self.icon_side = PhotoImage(file="images/side_icon.png")

#         Label_menu = Label(Leftmenu,text="Menu",font=("times new roman",20) , bg="#009688").pack(side=TOP,fill=X)
#         btn_employee = Button(Leftmenu,text="Employee",image= self.icon_side,compound=LEFT,padx=5,anchor="w",font=("times new roman",20,"bold") , bg="white",bd=3,cursor="hand2").pack(side=TOP,fill=X)
#         btn_supplier = Button(Leftmenu,text="Supplier",image= self.icon_side,compound=LEFT,padx=5,anchor="w",font=("times new roman",20,"bold") , bg="white",bd=3,cursor="hand2").pack(side=TOP,fill=X)
#         btn_category = Button(Leftmenu,text="Category",image= self.icon_side,compound=LEFT,padx=5,anchor="w",font=("times new roman",20,"bold") , bg="white",bd=3,cursor="hand2").pack(side=TOP,fill=X)
#         btn_prodcuts = Button(Leftmenu,text="Products",image= self.icon_side,compound=LEFT,padx=5,anchor="w",font=("times new roman",20,"bold") , bg="white",bd=3,cursor="hand2").pack(side=TOP,fill=X)
#         btn_sales = Button(Leftmenu,text="Sales",image= self.icon_side,compound=LEFT,padx=5,anchor="w",font=("times new roman",20,"bold") , bg="white",bd=3,cursor="hand2").pack(side=TOP,fill=X)
#         btn_exit = Button(Leftmenu,text="Exit",image= self.icon_side,compound=LEFT,padx=5,anchor="w",font=("times new roman",20,"bold") , bg="white",bd=3,cursor="hand2").pack(side=TOP,fill=X)


#         # content
#         self.lbl_employee = Label(self.root,text="Total Employee \n [ 0 ]",bg="blue",fg"white",font=("goudy old style",20,"bold"))
#         self.lbl_employee.place(x=300,y=120,height=150,widht=300)


#         #footer 
#         lbl_clock = Label(self.root,text="IMS | Developed by BRCK \n For any tech issues contact : xxxxxxxxx ",font=("times new roman",12),bg="#4d636d",fg="white").pack(side=BOTTOM,fill=X)

# root = Tk()
# obj = IMS(root)
# # root.mainloop()